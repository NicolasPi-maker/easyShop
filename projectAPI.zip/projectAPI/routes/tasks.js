const express = require('express');
const router = express.Router();
const mysql = require('mysql');
const sqlQuery = require('../utils/mysql');
const {log} = require("debug");
const {json} = require("express");
const middlewares = require("../middlewares/authentificationMiddleware");

router.use(middlewares.authentificationMiddleWare);

/* Liste des todo */
router.get('/', function(req, res, next) {
  const user = req.user;
  log(user);
  sqlQuery(`SELECT count(id) as count FROM tasks WHERE user_id = ${user.id}`, (err, results) => {
    const count = results[0].count;
    let page = (req.query.pages || 1) - 1 ;
    let limit = 5;
    const whereClause = {
      title : (value) => value,
    }
    let countPage = Math.round(count / limit);
    let isDone = req.query.done;
    let searchTitle = req.query.search;
    page = page < countPage ? page : 0;
    let query = `SELECT id, title, due_date, done, user_id FROM tasks WHERE user_id = ${user.id}`;
    // ${isDone ? 'AND done=1'  : 'AND done=0'} ${searchTitle ? `AND title Like '%${searchTitle}%'` : ''} LIMIT ${limit} OFFSET ${limit * page}
    try {
      sqlQuery(query, (error, results) => {
        res.json({
          "count": count,
          "hasPrev": page > 0,
          "hasNext": limit * (page + 1) < Math.max(count, limit),
          "results": results
        });
      })
    } catch (error) {
      res.writeHead(500);
      throw new Error(error);
    }
  })
});

/* Détail d'un todo */
router.get('/:id', function(req, res, next) {
  let taskId = req.params.id;
  const user = req.user;
  let query = `SELECT * FROM tasks WHERE id = ${taskId} AND user_id = ${user.id}`;
  try {
    sqlQuery(query, (error, results) => {
      res.json(results);
    })
  } catch (error) {
    res.status(500);
    throw new Error(error);
  }
});

/* Création d'un todo */
router.post('/', function(req, res, next) {
  const data = req.body;
  if(!data) {
    res.status(404);
    throw new Error('le produit est vide');
  }
  try {
    let query =
        `
          INSERT INTO tasks (title, due_date, done, description, user)
          VALUES ('${data.title}','${data.due_date}','${data.done}', '${data.description}', '${data.user.id}')
        `;
    sqlQuery(query, (error, results) => {
      res.json(results);
      res.status(201);
    })
  } catch (error) {
    res.status(error.status);
    throw new Error('Une erreur serveur est survenue');
  }
});

/* Mise à jour partielle */
router.patch('/:id', function(req, res, next) {
  let taskId = req.params.id;
  const user = req.user;
  const data = req.body;
  let query = `UPDATE tasks SET title = '${data.title}', description = '${data.description}', due_date = '${data.due_date}', done = '${data.done}' WHERE id = '${taskId} AND user_id = '${user.id}`;
  try {
    sqlQuery(query, (error, results) => {
      res.json(results);
      res.status(204);
    })
  } catch (error) {
    res.status(error.status);
    throw new Error('Une erreur serveur est survenue');
  }
});

/* Suppression d'un todo */
router.delete('/:id', function(req, res, next) {
  let taskId = req.params.id;
  if(taskId !== -1) {
    try {
      let query = `DELETE FROM tasks WHERE id = ${taskId}`;
      sqlQuery(query, (error, result) => {
        res.json(result);
        res.status(204);
      })
    } catch (error) {
      res.status(error.status)
      throw new Error(error);
    }
  } else {
    res.status(404)
  }
});

module.exports = router;
